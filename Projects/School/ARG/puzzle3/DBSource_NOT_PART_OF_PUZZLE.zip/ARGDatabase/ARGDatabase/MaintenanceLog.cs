﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase;

public class MaintenanceLog : Log
{
    public string Title => "Maintenance Log " + ID;

    public string ID { get; set; }
    public string PlantID { get; set; }
    public string Date { get; set; }

    public string Description { get; set; }
    public string PartsReplaced { get; set; }
    public string Cost { get; set; }
    public string AdditionalInfo { get; set; }

    public MaintenanceLog(string id, string plantID, string date, string description, string partsReplaced, string cost, string additionalInfo)
    {
        ID = id;
        PlantID = plantID;
        Date = date;
        Description = description;
        PartsReplaced = partsReplaced;
        Cost = cost;
        AdditionalInfo = additionalInfo;
    }

    public void Print()
    {
        InOut.WriteLine("Maintenance log " + ID);
        InOut.WriteLine("Plant ID: " + PlantID);
        InOut.WriteLine("Date: " + Date);
        InOut.Space();

        InOut.WriteLine("Description:\n" + Description);
        InOut.Space();

        InOut.WriteLine("Parts replaced:\n" + PartsReplaced);
        InOut.Space();

        InOut.WriteLine("Cost:\n" + Cost);
        InOut.Space();

        InOut.WriteLine("Additional info:\n" + AdditionalInfo);
    }
}
