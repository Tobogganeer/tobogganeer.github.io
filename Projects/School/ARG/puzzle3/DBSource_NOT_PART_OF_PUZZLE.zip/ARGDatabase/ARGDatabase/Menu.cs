﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase;

public class Menu
{
    public List<Option> options;

    // Constructors
    public Menu()
    {
        options = new List<Option>();
    }
    public Menu(params Option[] options) : base()
    {
        foreach (Option op in options)
        {
            this.options.Add(op);
        }
    }

    // Tuple way is easier to write in one line
    public Menu(params (string label, Action action)[] options) : base()
    {
        foreach ((string label, Action action) op in options)
        {
            this.options.Add(new Option(op));
        }
    }


    // Allows for chaining
    // eg menu.Add(op1).Add(op2);
    public Menu Add(Option option)
    {
        options.Add(option);
        return this;
    }
    public Menu Add((string label, Action action) option)
    {
        return Add(new Option(option));
    }
    public Menu Add(string label, Action action)
    {
        return Add(new Option(label, action));
    }

    // Same idea
    public Menu AddOptions(params Option[] options)
    {
        foreach (var op in options)
            Add(op);
        return this;
    }
    public Menu AddOptions(params (string label, Action action)[] options)
    {
        foreach (var op in options)
            Add(op);
        return this;
    }


    // Make the user select a choice
    public void Display(Action refreshCallback)
    {
        Write(options, 0);

        int selected = 0;

        // Capture input: if the user presses down or up, go down or up
        ConsoleKeyInfo keyinfo;
        do
        {
            keyinfo = Console.ReadKey(true);

            if (keyinfo.Key == ConsoleKey.DownArrow)
            {
                selected++;
                if (selected > options.Count - 1)
                    selected = 0;
                refreshCallback();
                Write(options, selected);
            }
            if (keyinfo.Key == ConsoleKey.UpArrow)
            {
                selected--;
                if (selected < 0)
                    selected = options.Count - 1;
                refreshCallback();
                Write(options, selected);
            }
        }
        while (keyinfo.Key != ConsoleKey.Enter);

        options[selected]?.Action?.Invoke();
    }

    void Write(List<Option> choices, int selected)
    {
        // Write all the options in a list, the selected with an arrow beside it

        //InOut.WriteLine("(Up and Down arrows to navigate, enter to choose)");
        for (int i = 0; i < choices.Count; i++)
        {
            if (i == selected)
            {
                InOut.WriteLine("> " + choices[i].Label);
            }
            else
            {
                InOut.WriteLine("  " + choices[i].Label);
            }
        }
    }
}
