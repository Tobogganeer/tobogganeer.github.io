﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ARGDatabase.Pages;

public class PlantControlPage : Page
{
    readonly List<string> ValidLocations = new List<string>{ "almaty", "russia", "china", "arctic", "arctic ocean", "ocean", "artic" };

    public PlantControlPage(string title, Program program) : base(title, program)
    {

    }

    public override void Display()
    {
        base.Display();
        InOut.WriteLine("(Press escape to return)");
        InOut.Write("Enter plant location: ");
        bool entered = InOut.ReadStringEscapablePredicate(out string path,
            TryPlant, "A valid plant location");
        if (entered)
        {
            //WaitDots($"Requesting access to {path.ToUpper()}", 3, 0.75f);
            InOut.WriteLine("Access granted.");
            Wait(1.0f);
            InOut.Space();

            WaitDots("Requesting file", 6, 0.65f);
            InOut.WriteLine("Request received.");
            InOut.Space();

            WaitDots("Downloading file", 4, 0.65f);

            // Oopsies
            ConsoleColor current = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Red;
            InOut.WriteLine("ERROR: UNAUTHORIZED ACCESS DETECTED - REPORT SENT TO 05-COUNCIL");
            Console.ForegroundColor = current;
            Wait(1.5f);
            WaitDots("", 7, 0.65f);
            InOut.Space();

            InOut.WriteLine("Plant file received.");
            Wait(1f);

            InOut.WriteLine("PROGRAM TERMINATED");
            Wait(2f);

            System.Diagnostics.Process.Start("explorer.exe", "http://tobo.games/ARG/puzzle4/index.html");

            InOut.WaitForInput();
            program.Back(true);
        }
        else
        {
            program.Back();
        }
    }

    bool TryPlant(string plant)
    {
        WaitDots($"Requesting access to {plant.ToUpper()}", 3, 0.75f);
        bool valid = ValidLocations.Contains(plant.ToLower());
        if (!valid)
            InOut.WriteLine("Plant not found.");

        return valid;
    }

    void WaitDots(string message, int dots, float secondsPerDot)
    {
        InOut.Write(message);

        for (int i = 0; i < dots; i++)
        {
            Wait(secondsPerDot);
            InOut.Write(".");
        }
        // Wait one last time
        Wait(secondsPerDot);
        InOut.WriteLine("");
    }

    void Wait(float seconds)
    {
        Thread.Sleep((int)(seconds * 1000f));
    }
}
