﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ARGDatabase.Pages;

/*
public class OpenRecipeListPage : Page
{
    public OpenRecipeListPage(Program program) : base("Open recent", program)
    {
        
    }

    public override void Display()
    {
        base.Display();
        InOut.WriteLine("(Press escape to return)");
        InOut.Write("Enter recipe list csv path: ");
        bool entered = InOut.ReadStringEscapablePredicate(out string path,
            (str) => File.Exists(str) && str.ToLower().EndsWith(".csv"), "A valid path to a .csv file");
        if (entered)
        {
            // In case of relative path
            path = Path.GetFullPath(path);
            RecentlyOpened.Add(path);
            program.Back(false);
            program.Goto(new RecipeListPage(program, RecipeList.Import(path)));
        }
        else
        {
            program.Back();
        }
    }
}
*/

