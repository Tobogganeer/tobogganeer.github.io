﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

/*
public class SelectRecipeListPage : MenuPage
{
    public SelectRecipeListPage(Program program) : base("Select", program)
    {
        FillMenu();
    }

    void FillMenu()
    {
        menu.options.Clear();

        // No files
        if (RecentlyOpened.Count == 0)
        {
            menu.Add(("Open a file", GotoOpenPage));
            menu.Add(("Back", () => program.Back(true)));
            return;
        }

        foreach (var file in RecentlyOpened.RecentFiles)
        {
            if (file.FileExists)
            {
                menu.Add(($"- {file.Title} : {file.Path}", () => SelectList(file)));
            }
            else
            {
                menu.Add(($"- (File not found) : {file.Path}", () => RemoveList(file)));
            }
        }

        menu.Add("Clear All", ClearAll);
        menu.Add("Open data file", OpenDataFile);
        menu.Add("Back", () => program.Back(true));
    }

    public override void Display()
    {
        base.Display();
        /*
        program.WriteHeader();

        OnMenuRefresh();

        DisplayMenu();
        *
    }

    protected override void OnMenuRefresh()
    {
        if (RecentlyOpened.Count == 0)
            InOut.WriteLine("No recently opened files.\n");
        else
        {
            // If there are lots, give a little hint
            if (RecentlyOpened.Count > 10)
                InOut.WriteLine("Select a recently opened file (more options at the bottom)");
            else
                InOut.WriteLine("Select a recently opened file");
            InOut.WriteLine("(Select an invalid file to remove it)\n");
        }
    }

    private void SelectList(RecentlyOpened.RecipeListFile file)
    {
        RecipeList list = RecipeList.Import(file.Path);
        if (list == null)
        {
            InOut.WriteLine("Invalid list. Removing from recently opened...");
            RecentlyOpened.RecentFiles.Remove(file);
            RecentlyOpened.Save();
            InOut.WaitForInput();
            FillMenu();
            Display();
            return;
        }

        program.Back(false);
        program.Goto(new RecipeListPage(program, list));
    }

    private void RemoveList(RecentlyOpened.RecipeListFile file)
    {
        // Return to menu
        RecentlyOpened.RecentFiles.Remove(file);
        RecentlyOpened.Save();
        FillMenu();
        Display();
    }

    private void ClearAll()
    {
        RecentlyOpened.RecentFiles.Clear();
        RecentlyOpened.Save();
    }

    private void GotoOpenPage()
    {
        program.Back(false);
        program.Goto(new OpenRecipeListPage(program));
    }

    private void OpenDataFile()
    {
        OpenFolder.To(RecentlyOpened.FilePath);
        //program.Back(false);
        //program.Goto(new SelectRecipeListPage(program));
        //program.Goto(this);
        Display();
    }
}
*/
