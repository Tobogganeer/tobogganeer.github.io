﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

public class _MenuPage : MenuPage
{
    public _MenuPage(Program program) : base("Title Here", program)
    {
        // Add options here
    }

    public override void Display()
    {
        base.Display();
    }
}
