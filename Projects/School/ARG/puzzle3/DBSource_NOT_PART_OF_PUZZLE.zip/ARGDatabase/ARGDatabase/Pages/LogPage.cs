﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

public class LogPage : Page
{
    Log log;

    public LogPage(Log log, Program program) : base(log.Title, program)
    {
        this.log = log;
    }

    public override void Display()
    {
        base.Display();
        log.Print();
        InOut.WaitForInput();
        program.Back();
    }
}
