﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

public class LogsPage : MenuPage
{
    List<Log> logs;

    public LogsPage(string title, Program program, List<Log> logs) : base(title, program)
    {
        this.logs = logs;

        foreach (var log in logs)
        {
            menu.Add("- " + log.Title, () => program.Goto(new LogPage(log, program)));
        }

        menu.Add("Back", () => program.Back(true));
    }

    public override void Display()
    {
        program.WriteHeader();

        OnMenuRefresh();

        DisplayMenu();
    }

    protected override void OnMenuRefresh()
    {
        InOut.WriteLine(Title + " - " + logs.Count + " logs");
    }
}
