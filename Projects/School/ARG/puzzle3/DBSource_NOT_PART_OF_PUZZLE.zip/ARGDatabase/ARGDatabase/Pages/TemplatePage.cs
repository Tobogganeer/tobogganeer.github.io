﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

public class _Page : Page
{
    public _Page(string title, Program program) : base(title, program)
    {

    }

    public override void Display()
    {
        base.Display();
    }
}
