﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

public class MaintenanceLogsPage : MenuPage
{
    public MaintenanceLogsPage(string title, Program program) : base(title, program)
    {

    }

    public override void Display()
    {
        base.Display();
    }
}
