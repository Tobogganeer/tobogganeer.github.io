﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

public class TitlePage : MenuPage
{
    List<Log> anomalyLogs = new List<Log>
    {
        new AnomalyLog("ALM_6-06", "9926", "9/02/2006", "09:45 UTC", "Immediate termination of Earth-5 members was carried out.\n" +
            "Footage of the execution was broadcast globally to Earth-5 to deter future attacks.",
            "Violent vibrations were caused due to a B-class event.\n" +
            "[REDACTED] members of Earth-5 attempted to cross the dimensional boundry.\n" +
            "At least 6 members carried A-class munitions which detonated approximately 17 seconds after crossing the dimensional boundry.\n" +
            "Members were detained and questioned. A known rebellion group took responsibility for the attack.",
            "Plant 9926 lost power for approximately 23 seconds while backup generators came online.\n" +
            "Disruption to dimensional transfer caused minimal damage. Various pieces of boundry equipment required repair due to blast damage.",
            "Approximately $6.3m USD",
            "Power loss and tremors were felt at the surface of the plant's location. Mireson agents planted in meteorological organizations publicized the event as an earthquake.\n" +
            "A civilian video of the event on the surface can be found at https://www.youtube.com/watch?v=aWL260hky9U"),
        new AnomalyLog("ARC_2_09", "0164", "11/04/2014", "04:43 UTC", "Interogation and termination of aggressors was carried out.\n" +
            "Hardening of internal systems was carried out to protect against future intrustions.\n" +
            "Further security staff was assigned to Plant 0164",
            "[REDACTED] members from various Duplicates covertly crossed the dimensional boundry and entered into Plant 0164 systems in an attempt to siphon data from internal servers. " +
            "System monitors logged anomalous data entries. Overwatch staff observed motion detector activations around the east wing of " +
            "Plant 0164 (around 83.9586061,-134.9353405) and security teams were dispatched.\n" +
            "Members were offered an ultimatum to work for Mireson, but all members refused, stating that Mireson was draining their planets of resources.",
            "System intrustion caused minimal damages, though plant security was reworked and all level 2 staff were re-trained on security procedures.\n" +
            "Firewall analysis showed that members did not extract any data from internal servers.",
            "Approximately $643k USD in initial anomaly containment, and approximately $4.3m USD in retraining and security hardening.",
            "No additional info."),
        new AnomalyLog("TRI_3_11", "2906", "8/04/2024", "15:13 UTC",
            "No containment required: Earth-54 destroyed.",
            "Duplicate Earth-54 was approved for destruction by the O5-council after production rates fell and rebellion rates increased.\n" +
            "Mireson staff at Plant 2906 successfully deployed several CT-class munitions across the dimensional boundry to Earth-54 at approximately 15:11 UTC. " +
            "Staff then overloaded the plant control network, causing Plant 2906 to close all boundaries to Earth-54.\n" +
            "Earth-54 then suffered a planned XK-class end-of-the-world scenario, resulting in destruction of the planet.",
            "At the time of destruction, Earth-54 accounted for approximately 2.3% of Mireson's total energy production.\n" +
            "Due to Mireson rationing and fertility control of Earth-54, the Duplicate had approximately 6.4 billion members, all of whom " +
            "were killed with the annihilation of their Duplicate.",
            "Approximately $6.2m USD in CT-class munitions were used.\n" +
            "The 2.3% drop in energy production will result in a $67k loss of profit until a new Duplicate is located and taken over.",
            "Several candidate Duplicates have been identified - see [REDACTED] for details (level 3 access required).\n" +
            "Destruction of Earth-54 was coincided with a local solar eclipse to draw attention away from potential rebellion attempts by Earth-54 members."),
    };
    List<Log> maintenanceLog = new List<Log>
    {
        new MaintenanceLog("ALM_6-06", "9926", "9-21/02/2006", "Boundary equipment repaired due to blast damage",
            "Dimensional Alternator\n" +
            "Control Console\n" +
            "Flux Tubing (port and aft)\n" +
            "Boundary Gate nuts (port)\n" +
            "Various ground and wall tiles",
            "Approximately $21k in replacement parts and 10 work days", "No additional info."),
        new MaintenanceLog("TDI_2_01", "4812", "22/05/2023", "Installed vending machine due to employee request",
            "Vending machine",
            "Approximately $1.2k for equipment and rewiring, $23/month in refilling", "Employee morale improvement expected.")
    };

    public TitlePage(Program p) : base("Main Menu", p)
    {
        // Options
        menu.Add("Plant Control", () => program.Goto(new PlantControlPage("Plant Control", p)))
            .Add("[REDACTED]", null)
            .Add("Maintenance Logs", () => program.Goto(new LogsPage("Maintenance Logs", p, maintenanceLog)))
            .Add("Anomaly Logs", () => program.Goto(new LogsPage("Anomaly Logs", p, anomalyLogs)))
            .Add("[REDACTED]", null)
            .Add("[REDACTED]", null);
    }

    public override void Display()
    {
        base.Display();
    }
}
