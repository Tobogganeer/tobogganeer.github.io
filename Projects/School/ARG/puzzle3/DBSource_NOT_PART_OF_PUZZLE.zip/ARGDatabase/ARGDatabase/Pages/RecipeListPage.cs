﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

/*
public class RecipeListPage : MenuPage
{
    public RecipeList RecipeList { get; set; }

    public RecipeListPage(Program program, RecipeList recipeList) : base(recipeList.Name, program)
    {
        RecipeList = recipeList;

        foreach (Recipe recipe in recipeList.Recipes)
        {
            menu.Add("- " + recipe.Title, () => program.Goto(new RecipePage(program, recipeList, recipe)));
        }

        menu.Add("Back", () => program.Back(true));
    }

    public override void Display()
    {
        program.WriteHeader();

        OnMenuRefresh();

        DisplayMenu();
    }

    protected override void OnMenuRefresh()
    {
        InOut.WriteLine(RecipeList.Name + " - " + RecipeList.Count + " recipes");
    }
}
*/
