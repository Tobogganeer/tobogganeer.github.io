﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase.Pages;

/*
public class RecipePage : MenuPage
{
    public RecipeList RecipeList { get; set; }
    public Recipe Recipe { get; set; }

    public RecipePage(Program program, RecipeList list, Recipe recipe) : base(recipe.Title, program)
    {
        RecipeList = list;
        Recipe = recipe;

        // Add options here

        menu.Add("Display Ingredients (can specify servings)", DisplayIngredients);
        menu.Add("Display Instructions", () => DisplayRecipe(false, true));
        menu.Add("Display All", () => DisplayRecipe(true, true));
        menu.Add($"Remove from {list.Name}", RemoveFromList);
        menu.Add("Back", () => program.Back(true));
    }

    public override void Display()
    {
        base.Display();
    }

    protected override void OnMenuRefresh()
    {
        InOut.WriteLine($"{Recipe.Title} - {Recipe.Servings} servings" +
            $" - {Recipe.IngredientCount} ingredients - {Recipe.InstructionList.Count} steps");
    }

    private void DisplayRecipe(bool ingredients, bool instructions)
    {
        //Console.In.
        InOut.Clear();
        InOut.WriteLine("\n" + Recipe.HeaderString());
        if (ingredients)
            InOut.WriteLine(Recipe.IngredientsString());
        if (instructions)
            InOut.WriteLine(Recipe.InstructionsString());
        InOut.WaitForInput();
        Display();
    }

    private void DisplayIngredients()
    {
        float servings = InOut.ReadInt("Input how many servings you would like: ");
        if (servings < 0) servings = 1;

        float percent = Recipe.Servings / servings;

        InOut.Clear();
        InOut.WriteLine("\n" + Recipe.HeaderString());
        InOut.WriteLine(Recipe.IngredientsString(percent));
        InOut.WaitForInput();
        Display();
    }

    private void RemoveFromList()
    {
        // Just double check
        if (InOut.Confirm($"Are you sure you'd like to remove {Recipe.Title} from {RecipeList.Name}?"))
        {
            // Remove it and save it
            RecipeList.Recipes.Remove(Recipe);
            RecipeList.Save();
            InOut.WriteLine($"{RecipeList} removed, changes saved.");
            InOut.WaitForInput();
            program.Back();
        }
        else
        {
            // Just return to this page
            //program.Back(false);
            //program.Goto(this);
            Display();
        }
    }
}
*/