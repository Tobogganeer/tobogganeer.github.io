﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ARGDatabase.Pages;

namespace ARGDatabase;

public class Entrypoint
{
    static void Main(string[] args)
    {
        Program program = new Program("[COMPANY NAME] Management System");
        TitlePage titlePage = new TitlePage(program);

        try
        {
            while (true)
            {
                program.Run(titlePage);
                program.History.Clear();
            }
        }
        catch (Exception ex)
        {
            if (ex is ExitAppException)
            {
                InOut.Clear();
                InOut.WriteLine("Logged out successfully...");
                InOut.WaitForInput();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                InOut.WriteLine("EXCEPTION: " + ex.ToString());
                Console.ResetColor();
                InOut.WaitForInput();
                throw;
            }
        }
    }
}

// Provides and interesting way to exit
public class ExitAppException : Exception { }
