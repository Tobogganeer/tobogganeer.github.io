﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase;

// This will be used often, so make it a thingy
public class MenuPage : Page
{
    protected Menu menu;

    // Basically just calling the menu constructors
    public MenuPage(string title, Program program,
        params (string label, Action action)[] options) : base(title, program)
    {
        menu = new Menu(options);
    }

    public MenuPage(string title, Program program,
        params Option[] options) : base(title, program)
    {
        menu = new Menu(options);
    }

    // Basic constructor
    public MenuPage(string title, Program program) : base(title, program)
    {
        menu = new Menu();
    }

    // Easy ways to add options
    public void AddOption(Option op) => menu.options.Add(op);
    public void AddOption((string label, Action action) option) => AddOption(new Option(option));

    public override void Display()
    {
        base.Display();
        OnMenuRefresh();
        DisplayMenu();
    }

    protected void DisplayMenu()
    {
        menu.Display(RefreshCallback);
    }

    void RefreshCallback()
    {
        program.WriteHeader();
        OnMenuRefresh();
    }

    protected virtual void OnMenuRefresh() { }
}
