﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase;

public class Option
{
    public string Label { get; set; }
    public Action Action { get; set; }

    public Option(string label, Action action)
    {
        Label = label;
        Action = action;
    }

    public Option((string label, Action action) tuple)
    {
        Label = tuple.label;
        Action = tuple.action;
    }
}
