﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase;

public interface Log
{
    string Title { get; }
    void Print();
}
