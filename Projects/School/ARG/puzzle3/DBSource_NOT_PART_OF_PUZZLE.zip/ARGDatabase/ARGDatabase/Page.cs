﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase;

public abstract class Page
{
    public string Title { get; set; }
    protected Program program;

    public Page(string title, Program program)
    {
        Title = title;
        this.program = program;
    }

    public virtual void Display()
    {
        program.WriteHeader();
    }
}
