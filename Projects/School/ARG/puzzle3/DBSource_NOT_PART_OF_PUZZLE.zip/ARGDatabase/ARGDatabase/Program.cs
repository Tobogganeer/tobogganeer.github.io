﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase;

public class Program
{
    public readonly string Name;
    public Stack<Page> History;
    public Page CurrentPage => History.Any() ? History.Peek() : null;

    public Program(string name)
    {
        Name = name;
        History = new Stack<Page>();
    }

    public void Run(Page defaultPage)
    {
        History.Push(defaultPage);
        CurrentPage.Display();
    }

    public void WriteHeader()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(Name);

        // Otherwise it goes in the wrong order
        foreach (Page page in History.Reverse())
        {
            sb.Append(page.Title); sb.Append(" > ");
        }

        sb.Remove(sb.Length - 3, 3); // Remove trailing " > "

        sb.AppendLine("\n=== (Up & Down to navigate, enter to select) ===");

        //Name
        //Page 1 > Page 2
        //===

        InOut.Clear();
        InOut.WriteLine(sb.ToString());
    }

    public void Goto(Page page)
    {
        History.Push(page);
        CurrentPage.Display();
    }

    public void Back(bool display = true)
    {
        History.Pop();
        if (display)
            CurrentPage.Display();
        // You don't always want to display the new page,
        //  you might just be going to another one
        // i.e I go from
        // Main > Select
        // Main
        // Main > Open
        // and don't want to display the main screen along the way
    }

    public static void Exit()
    {
        throw new ExitAppException();
    }
}
