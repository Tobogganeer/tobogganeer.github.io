﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARGDatabase;

public class AnomalyLog : Log
{
    public string Title => "Anomaly Log " + ID;

    public string ID { get; set; }
    public string PlantID { get; set; }
    public string Date { get; set; }
    public string Time { get; set; }

    public string ContainmentProcedures { get; set; }
    public string Description { get; set; }
    public string Impact { get; set; }
    public string Cost { get; set; }
    public string AdditionalInfo { get; set; }

    public AnomalyLog(string id, string plantID, string date, string time, string containmentProcedures, string description, string impact, string cost, string additionalInfo)
    {
        ID = id;
        PlantID = plantID;
        Date = date;
        Time = time;
        ContainmentProcedures = containmentProcedures;
        Description = description;
        Impact = impact;
        Cost = cost;
        AdditionalInfo = additionalInfo;
    }

    public void Print()
    {
        InOut.WriteLine("Maintenance log " + ID);
        InOut.WriteLine("Plant ID: " + PlantID);
        InOut.WriteLine("Date: " + Date);
        InOut.WriteLine("Time: " + Time);
        InOut.Space();

        InOut.WriteLine("Containment procedures:\n" + ContainmentProcedures);
        InOut.Space();

        InOut.WriteLine("Description:\n" + Description);
        InOut.Space();

        InOut.WriteLine("Impact:\n" + Impact);
        InOut.Space();

        InOut.WriteLine("Cost:\n" + Cost);
        InOut.Space();

        InOut.WriteLine("Additional info:\n" + AdditionalInfo);
    }
}
