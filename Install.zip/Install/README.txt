# Quick Sheridan sign-in
# Created by (a very frustrated) Sheridan student


# ========== SETUP ========== #
#
#   1. Edit Install.py to set which email you use for Visual Studio (TODO: Allow for no email)
#   2. Run PasswordCreator.py to create your encrypted passwords file
#   3. Save the zip someone like OneDrive or Google Drive where you can download it later
#

# ========== HOW TO USE ========== #
#
#   1. Set Google Chrome as the default browser (TODO: set it automatically later?)
#   2. Download your uploaded files from wherever you put them
#   2. Use run.bat to run the program
#   3. Input your master password
#   4. Input 2FA codes as asked after setup is complete
#